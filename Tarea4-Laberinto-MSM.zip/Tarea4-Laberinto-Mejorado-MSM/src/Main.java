import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static final Scanner sc = new Scanner(System.in);

    //Creacion del laberinto
    private static char[][] laberinto ={
            {'x','x','x','x','x','x','x','x','x','x','x','x'},
            {'x','E','0','0','0','0','x','x','x','x','x','x'},
            {'x','x','x','x','x','0','x','x','x','x','x','x'},
            {'x','x','x','x','x','0','0','0','x','x','x','x'},
            {'x','x','x','x','x','x','x','0','x','x','x','x'},
            {'x','x','x','x','x','x','x','0','0','0','S','x'},
            {'x','x','x','x','x','x','x','x','x','x','x','x'},
    };

    //Otro laberinto
//    private static char[][] laberinto ={
//            {'x','x','x','x','x','x','x','x','x','x','x','x'},
//            {'x','x','x','x','0','0','0','0','x','x','x','x'},
//            {'x','x','x','x','0','x','x','0','x','x','x','x'},
//            {'x','E','0','0','0','x','x','0','x','x','x','x'},
//            {'x','x','x','x','x','x','x','0','x','x','x','x'},
//            {'x','x','x','x','x','x','x','0','0','0','0','S'},
//            {'x','x','x','x','x','x','x','x','x','x','x','x'},
//    };

    //Otro laberinto, este sin entrada pero con salida
//    private static char[][] laberinto ={
//            {'x','x','x','x','x','x','x','x','x','x','x','x'},
//            {'x','x','0','0','0','0','x','x','x','x','x','x'},
//            {'x','x','x','x','x','0','x','x','x','x','x','x'},
//            {'x','x','x','x','x','0','0','0','x','x','x','x'},
//            {'x','x','x','x','x','x','x','0','x','x','x','x'},
//            {'x','x','x','x','x','x','x','0','0','0','S','x'},
//            {'x','x','x','x','x','x','x','x','x','x','x','x'},
//    };

    private static boolean salida=false;

    public static void main(String[] args) {
        ArrayList<String> coordenadas=new ArrayList<>();
        int [] posicion= encontrarSalida();
        boolean hayEntrada=buscarEntrada();
        boolean haySalida=false;
        int movimientos=20;
        int contador=0;

        if (hayEntrada){
            if (contador<movimientos){
                String mov;
                while (!salida){
                    //Mostrar el laberinto
                    mostrarMapa(posicion);

                    System.out.println("Mover (w/a/s/d)");
                    mov=sc.nextLine();

                    switch (mov){
                        case "w":
                            //Mover personaje para arriba
                            moverPersonaje(posicion,-1,0,coordenadas);
                            break;
                        case "s":
                            //Mover personaje para abajo
                            moverPersonaje(posicion,1,0,coordenadas);
                            break;
                        case "a":
                            //Mover personaje para izquierda
                            moverPersonaje(posicion,0,-1,coordenadas);
                            break;
                        case "d":
                            //Mover personaje para la derecha
                            moverPersonaje(posicion,0,1,coordenadas);
                            break;
                        default:
                            System.out.println("Comando invalido");
                    }
                    contador++;
                }
            }
        }else System.out.println("No hay ninguna entrada en el programa");

    }

    private static void mostrarMapa(int [] posicion){
        char [][] entradaPersonaje=new char[laberinto.length][laberinto[0].length];

        for (int i=0;i< laberinto.length;i++){
            for (int j=0;j< laberinto[0].length;j++){
                entradaPersonaje[i][j] = laberinto[i][j];
            }
        }

        entradaPersonaje[posicion[0]][posicion[1]]='P';

        for (int i = 0; i < entradaPersonaje.length; i++) {
            for (int j = 0; j < entradaPersonaje[0].length; j++) {
                System.out.print(entradaPersonaje[i][j]);
            }
            System.out.println();
        }

    }

    private static int[] encontrarSalida(){
        int [] posicion= new int[2];
        for (int i=0;i<laberinto.length;i++){
            for (int j=0;j<laberinto[0].length;j++){
                if (laberinto[i][j]=='E'){
                    posicion[0]=i;
                    posicion[1]=j;
                }
            }
        }
        return posicion;
    }

    private static void moverPersonaje(int [] posicion, int x, int y, ArrayList<String> coordenadas){
        int posx=posicion[0]+x;
        int posy=posicion[1]+y;
        //Verificar si cuando me muevo no me salgo de los limites del mapa
        if (posx>=0 && posx < laberinto.length && posy>=0 && posy< laberinto[0].length){
            char nuevoLugar =laberinto[posx][posy];
            if (nuevoLugar=='0'){
                posicion[0]=posx;
                posicion[1]=posy;
                //Aqui guardo las coordenadas que ha usado para llegar al camino final
                coordenadas.add("("+posx+")"+","+"("+posy+")");
            } else if (nuevoLugar == 'S') {
                System.out.println("¡Felicidades! Has conseguido salir del laberinto");
                coordenadas.add("("+posx+")"+","+"("+posy+")");
                System.out.println("Este es el camino que has cogido para llegar a la salida:");
                for (String c : coordenadas){
                    System.out.println(c);
                }
                salida=true;
            }else if (!salida){
                System.out.println("No se ha encontrado ninguna salida");
                for (String c : coordenadas){
                    System.out.println(c);
                }
                salida=true;
            }
        }


    }

    private static boolean buscarEntrada(){
        boolean hayEntrada=false;
        for (int i=0;i< laberinto.length;i++){
            for (int j=0;j< laberinto[0].length;j++){
                if (laberinto[i][j]=='E'){
                    hayEntrada=true;
                    return hayEntrada;
                }
            }
        }
        return hayEntrada;
    }
}